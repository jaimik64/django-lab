from django.apps import AppConfig


class CrudOperationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Crud_operations'
