from django.contrib import admin

from .models import Login,UserExtraData
admin.site.register(Login)
admin.site.register(UserExtraData)
