from django.db import models

# Create your models here.

class Posts(models.Model):
    title = models.CharField(max_length=250)
    description = models.CharField(max_length=250)
    like = models.CharField(max_length=10)
    dislike = models.CharField(max_length=10)