from django.contrib import admin

# jaimik : Admin@123
# Register your models here.
from .models import User
admin.site.register(User)
