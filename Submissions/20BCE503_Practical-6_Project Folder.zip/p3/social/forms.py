from django import forms
from .models import User

class CreateUserForm(forms.ModelForm):
    name = forms.CharField(label="Name")
    email = forms.EmailField(label="Email Id")
    password = forms.CharField(label="Password", widget=forms.PasswordInput)
    username = forms.CharField(label="User Name")
    birthdate = forms.DateField(label="Birth Date")
    gender = forms.MultipleChoiceField(label="Gender", required=False, widget=forms.RadioSelect(choices=[("male", "Male"), ("female", "Female")]))

    class Meta:
        model = User
        fields=['name', 'email','password', 'username', 'birthdate', 'gender']
        