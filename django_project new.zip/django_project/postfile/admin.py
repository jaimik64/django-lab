from django.contrib import admin

# Register your models here.
from .models import PostFile1

admin.site.register(PostFile1)